import 'package:NewApp/loading.dart';
import 'package:NewApp/services/auth.dart';
import 'package:flutter/material.dart';
import 'forgotPassword.dart';
import 'package:flutter_signin_button/flutter_signin_button.dart';
import 'package:NewApp/screen/navigator.dart';
import 'package:NewApp/register.dart';
import 'global.dart' as globals; //access global variable

class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final AuthService _auth = AuthService();
  final _formKey = GlobalKey<FormState>();
  String error = '';

  // text field state
  //String email = '';
  String password = '';

  //for loading widget
  bool loading = false;
  @override

  // Toggles the password to show status
  bool _obscureText = true;
  void _toggle() {
    setState(() {
      _obscureText = !_obscureText;
    });
  }

  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    Color mainTheme = Color.fromARGB(255, 18, 10, 79);
    return loading
        ? Loading()
        : Scaffold(
            backgroundColor: Colors.white,
            body: Container(
              height: size.height,
              width: double.infinity,
              child: Form(
                key: _formKey,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Image.asset(
                        'assets/images/IEEEMY1.png',
                        height: size.height * 0.5,
                      ),
                      //email container design
                      Container(
                        width: size.width * 0.8,
                        padding: EdgeInsets.symmetric(
                          horizontal: 20.0,
                          vertical: 5.0,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.blue[50],
                          borderRadius: BorderRadius.circular(50.0),
                        ),
                        child: TextFormField(
                          validator: (val) =>
                              val!.isEmpty ? 'Enter an email' : null,
                          onChanged: (val) {
                            setState(() {
                              globals.email = val;
                            });
                          },
                          textInputAction: TextInputAction.done,
                          decoration: InputDecoration(
                            icon: Icon(
                              Icons.person,
                              color: mainTheme,
                            ),
                            hintStyle: TextStyle(
                              color: Colors.grey[500],
                              fontWeight: FontWeight.bold,
                            ),
                            hintText: 'Email or Username',
                            fillColor: Colors.white,
                            border: InputBorder.none,
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 20.0,
                      ),
                      //password container design
                      Container(
                        width: size.width * 0.8,
                        padding: EdgeInsets.symmetric(
                          horizontal: 20.0,
                          vertical: 5.0,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.blue[50],
                          borderRadius: BorderRadius.circular(50.0),
                        ),
                        child: TextFormField(
                          validator: (val) =>
                              val!.isEmpty ? 'Enter password' : null,
                          onChanged: (val) {
                            setState(() {
                              password = val;
                            });
                          },
                          textInputAction: TextInputAction.done,
                          obscureText: _obscureText,
                          decoration: InputDecoration(
                            icon: Icon(
                              Icons.lock_rounded,
                              color: mainTheme,
                            ),
                            suffixIcon: IconButton(
                              icon: Icon(Icons.visibility),
                              color: mainTheme,
                              onPressed: _toggle,
                            ),
                            hintStyle: TextStyle(
                              color: Colors.grey[500],
                              fontWeight: FontWeight.bold,
                            ),
                            hintText: 'Enter Your Password',
                            fillColor: Colors.white,
                            border: InputBorder.none,
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 5.0,
                      ),
                      //forgot password container design (yet to finish)
                      Container(
                        alignment: Alignment.centerRight,
                        width: size.width * 0.8,
                        child: FlatButton(
                          onPressed: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => ForgotPassword()));
                          },
                          child: Text(
                            'Forgot Password?',
                            style: TextStyle(
                              color: mainTheme,
                              fontSize: 15.0,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 10.0,
                      ),
                      //sign in button
                      Container(
                        width: size.width * 0.8,
                        padding: EdgeInsets.symmetric(vertical: 5.0),
                        child: RaisedButton(
                          elevation: 5.0,
                          onPressed: () async {
                            if (_formKey.currentState!.validate()) {
                              setState(() => loading = true);
                              dynamic result =
                                  await _auth.signInWithEmailAndPassword(
                                      globals.email, password);
                              if (result == null) {
                                setState(() {
                                  loading = false;
                                  error =
                                      'Could not sign in with those credentials';
                                });
                              } else {
                                //got issue here, should hv auto go to home screen without the following codes
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => MainNavigator()));
                              }
                            }
                          },
                          padding: EdgeInsets.all(15.0),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30.0),
                          ),
                          color: Colors.blue[50],
                          child: Text('LOGIN',
                              style: TextStyle(
                                  color: mainTheme,
                                  fontSize: 18.0,
                                  letterSpacing: 2.0,
                                  fontWeight: FontWeight.bold)),
                        ),
                      ),
                      SizedBox(height: 12.0),
                      Text(
                        error,
                        style: TextStyle(color: Colors.red, fontSize: 14.0),
                      ),
                      Container(
                        alignment: Alignment.center,
                        width: size.width * 0.8,
                        child: Text('-- Or --',
                            style: TextStyle(
                              color: mainTheme,
                              fontSize: 15.0,
                            )),
                      ),
                      SizedBox(
                        height: 20.0,
                      ),
                      //register container design (will be toggle to new window)
                      SignInButtonBuilder(
                        text: 'Register with Student Email',
                        icon: Icons.email,
                        onPressed: () {
                          Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => Register()));
                        },
                        backgroundColor: Color.fromARGB(255, 6, 10, 130),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
  }
}
