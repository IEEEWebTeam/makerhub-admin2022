import 'package:NewApp/screen/navigator.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:NewApp/constant.dart';

PreferredSize? customInventoryAppBar(context) {
  //for settings function
  void _showSettingsPanel() {
    showModalBottomSheet(
        context: context,
        builder: (context) {
          return Container(
            padding: EdgeInsets.symmetric(vertical: 20.0, horizontal: 60.0),
            //child: SettingsForm(),
          );
        });
  }

  return PreferredSize(
    preferredSize: Size.fromHeight(70),
    child: AppBar(
      elevation: 0,
      backgroundColor: Colors.transparent,
      leading: IconButton(
        icon: Icon(Icons.arrow_back_ios),
        color: darkTextColor,
        onPressed: () {
          Navigator.pushReplacement(context,
              MaterialPageRoute(builder: (context) => MainNavigator()));
        },
      ),
      centerTitle: true,
      title: Padding(
        padding: EdgeInsets.only(top: 8.0),
        child: Text(
          "Inventory",
          style: TextStyle(
            fontSize: 25,
            fontWeight: FontWeight.bold,
            color: darkTextColor,
          ),
        ),
      ),
      actions: [
        //editing icon
        Padding(
          padding: EdgeInsets.only(top: 8.0, right: 10.0),
          child: IconButton(
            icon: FaIcon(
              FontAwesomeIcons.pen,
              color: darkTextColor,
              size: 20,
            ),
            onPressed: () {
              //change amount
            },
          ),
        ),
      ],
    ),
  );
}
