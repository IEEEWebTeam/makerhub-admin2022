import 'package:NewApp/screen/inventory/widget/appbar.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:NewApp/constant.dart';

class InventoryPage extends StatefulWidget {
  @override
  _InventoryPageState createState() => _InventoryPageState();
}

class _InventoryPageState extends State<InventoryPage> {
  final db = FirebaseFirestore.instance;
  User? _currentUser = FirebaseAuth.instance.currentUser;
  Map<String, dynamic> _cartList = {};

  @override
  void initState() {
    var collection = FirebaseFirestore.instance.collection('members');
    var querySnapshot = collection.doc(_currentUser!.uid).get();
    querySnapshot.then((value) {
      _cartList = value.data()!['cart'];
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: customInventoryAppBar(context),
      body: StreamBuilder<QuerySnapshot>(
          stream: db.collection('Inventory').snapshots(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) {
              return Center(
                child: CircularProgressIndicator(),
              );
            }
            return ListView(
              children: snapshot.data!.docs.map((doc) {
                return Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                    ),
                    //height: 50,
                    margin: EdgeInsets.fromLTRB(0, 2, 0, 10),
                    padding: EdgeInsets.all(10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Expanded(
                          flex: 3,
                          child: Padding(
                            padding: EdgeInsets.fromLTRB(0, 0, 10, 0),
                            child: Text(
                              doc.id,
                              style: TextStyle(
                                fontSize: 15,
                              ),
                            ),
                          ),
                        ),
                        Expanded(
                          flex: 2,
                          child: Text(
                            "Available:\n" + doc.get("TotalAmount").toString(),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        ElevatedButton(
                          onPressed: () {
                            _cartList.update(doc.id, (value) => value + 1,
                                ifAbsent: () => 1);
                            db
                                .collection("members")
                                .doc(_currentUser!.uid)
                                .update({"cart": _cartList});
                            final snackBar = SnackBar(
                              content: const Text('Added To Cart !'),
                            );
                            ScaffoldMessenger.of(context)
                                .showSnackBar(snackBar);
                          },
                          style: ButtonStyle(
                              //fixedSize: ,
                              backgroundColor: MaterialStateProperty.all<Color>(
                                  Color.fromRGBO(0, 96, 128, 1))),
                          child: Row(
                            children: [
                              Icon(Icons.add_shopping_cart_outlined,
                                  color: Colors.white),
                              // Text("Add to Cart")
                            ],
                          ),
                        )
                      ],
                    ));
              }).toList(),
            );
          }),
    );
  }
}
