// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, unnecessary_brace_in_string_interps, sized_box_for_whitespace

import 'package:NewApp/loading.dart';
import 'package:flutter/material.dart';
import 'package:NewApp/animation/fadeanimation.dart';
import 'package:NewApp/constant.dart';
import 'package:NewApp/screen/cart/widget/emptylist.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:NewApp/screen/cart/widget/NumberPicker.dart';
import 'package:provider/provider.dart';
import 'package:NewApp/models/user.dart';
import 'package:NewApp/services/database.dart';

class BodyCart extends StatefulWidget {
  @override
  _BodyCartState createState() => _BodyCartState();
}

class _BodyCartState extends State<BodyCart>
    with SingleTickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;
    CollectionReference _memberdb =
        FirebaseFirestore.instance.collection("members");
    User _currentUser = FirebaseAuth.instance.currentUser!;
    return SingleChildScrollView(
        child: Container(
            margin: const EdgeInsets.all(10),
            width: width,
            height: height / 1.14,
            child: Column(
              children: [
                StreamBuilder<DocumentSnapshot<Object?>>(
                    stream: _memberdb.doc(_currentUser.uid).snapshots(),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData || snapshot.hasError) {
                        return Center(
                          child: Loading(),
                        );
                      }
                      var _data = (snapshot.data!.data()
                          as Map<String, dynamic>)['cart'];
                      if (_data == null) {
                        return EmptyList();
                      }
                      List<String> _keys = _data.keys.toList();
                      return Column(children: [
                        Container(
                          width: width,
                          height: height / 1.6,
                          child: ListView.builder(
                              itemCount: _data.length,
                              itemBuilder: (context, index) {
                                return Container(
                                  margin: EdgeInsets.fromLTRB(0, 2, 0, 10),
                                  padding: EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    color: Colors.grey[300],
                                  ),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: <Widget>[
                                      Expanded(
                                        child: Text(_keys[index]),
                                      ),
                                      Spacer(),
                                      NumberPicker(
                                          minValue: 0,
                                          maxValue: 100,
                                          value: _data[_keys[index]],
                                          onChange: (v) {}),
                                    ],
                                  ),
                                );
                              }),
                        ),
                        SizedBox(
                          height: 12,
                        ),
                        Container(
                          width: width,
                          height: height / 7,
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                              ),
                              SizedBox(
                                height: 20,
                              ),
                              materialButton(width, height)
                            ],
                          ),
                        ),
                      ]);
                    }),
              ],
            )));
  }
}

// Material Button Components
materialButton(width, height) {
  return MaterialButton(
    minWidth: width / 1.2,
    height: height / 15,
    color: materialButtonColor,
    onPressed: () {},
    child: Text(
      "NEXT",
      style: TextStyle(color: lightTextColor),
    ),
  );
}
