import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class NumberPicker extends StatefulWidget {
  final ShapeBorder? shape;
  final TextStyle? valueTextStyle;
  final Function(dynamic) onChange;
  final dynamic maxValue;
  final dynamic minValue;
  final value;

  NumberPicker({
    Key? key,
    this.shape,
    this.valueTextStyle,
    required this.onChange,
    required this.maxValue,
    required this.minValue,
    this.value,
  });

  @override
  State<StatefulWidget> createState() {
    return NumberPickerState();
  }
}

class NumberPickerState extends State<NumberPicker> {
  dynamic _value;
  dynamic _maxValue;
  dynamic _minValue;
  TextEditingController _controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    _value = widget.value;
    _maxValue = widget.maxValue;
    _minValue = widget.minValue;
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(4),
        // child: Expanded(
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            GestureDetector(
              onTap: minus,
              child: Padding(
                  padding:
                      EdgeInsets.only(left: 3, right: 3, bottom: 3, top: 3),
                  child: Icon(
                    Icons.remove_circle_outline,
                    size: 18,
                  )),
            ),
            Container(
              // margin: EdgeInsets.all(3),
              width: _textSize(widget.valueTextStyle ?? TextStyle(fontSize: 14))
                      .width +
                  10,

              child:
                  /*TextField(
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                onChanged: (value) {
                  enterNumber(int.parse(value));
                },
                decoration: InputDecoration(
                  isDense: true,
                  border: InputBorder.none,
                  hintText: "$_value",
                ),
                style: widget.valueTextStyle ?? TextStyle(fontSize: 14),
                textAlign: TextAlign.center,
              ),*/
                  Text(
                "$_value",
                style: widget.valueTextStyle ?? TextStyle(fontSize: 14),
                textAlign: TextAlign.center,
              ),
            ),
            GestureDetector(
              onTap: add,
              child: Padding(
                  padding:
                      EdgeInsets.only(left: 3, right: 3, bottom: 3, top: 3),
                  child: Icon(
                    Icons.add_circle_outline,
                    size: 18,
                  )),
            ),
          ],
        ),
      ),
      //  )
    );
  }

  Size _textSize(TextStyle style) {
    final TextPainter textPainter = TextPainter(
        text: TextSpan(text: _maxValue.toString(), style: style),
        maxLines: 1,
        textDirection: TextDirection.ltr)
      ..layout(
          minWidth: 0, maxWidth: _maxValue.toString().length * style.fontSize!);
    return textPainter.size;
  }

  void enterNumber(int num) {
    if (num > _maxValue || num < _minValue) {
      return;
    }
    setState(() {
      _value = num;
    });
    widget.onChange(_value);
  }

  void minus() {
    if (checkRange(DoAction.MINUS)) {
      setState(() {
        _value -= 1;
      });
    }
    widget.onChange(_value);
  }

  void add() {
    if (checkRange(DoAction.ADD)) {
      setState(() {
        _value += 1;
      });
    }
    widget.onChange(_value);
  }

  bool checkRange(DoAction action) {
    if (action == DoAction.MINUS) {
      return _value - 1 >= _minValue;
    }
    if (action == DoAction.ADD) {
      return _value + 1 <= _maxValue;
    }
    return false;
  }
}

enum DoAction { MINUS, ADD }
