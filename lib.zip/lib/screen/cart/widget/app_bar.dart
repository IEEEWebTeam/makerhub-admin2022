// ignore_for_file: prefer_const_constructors

import 'package:NewApp/screen/navigator.dart';
import 'package:flutter/material.dart';
import 'package:NewApp/constant.dart';

PreferredSize? customAppBarCart(ctx) {
  return PreferredSize(
    preferredSize: const Size.fromHeight(60),
    child: AppBar(
      elevation: 0,
      backgroundColor: Colors.transparent,
      centerTitle: true,
      title: Padding(
        padding: EdgeInsets.only(top: 8.0),
        child: Text(
          "My Cart",
          style: TextStyle(
            fontSize: 25,
            fontWeight: FontWeight.bold,
            color: darkTextColor,
          ),
        ),
      ),
      leading: IconButton(
        icon: Icon(Icons.arrow_back_ios),
        color: darkTextColor,
        onPressed: () {
          Navigator.pushReplacement(
              ctx, MaterialPageRoute(builder: (context) => MainNavigator()));
        },
      ),
    ),
  );
}
