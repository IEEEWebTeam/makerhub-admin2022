// ignore_for_file: use_key_in_widget_constructors

import 'package:NewApp/services/auth.dart';
import 'package:flutter/material.dart';
import 'package:NewApp/constant.dart';

import 'package:NewApp/screen/cart/widget/body.dart';
import 'widget/app_bar.dart';

class MyCartScreen extends StatelessWidget {
  final AuthService _auth = AuthService();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: backgroundColor,
        appBar: customAppBarCart(context),
        body: BodyCart(),
      ),
    );
  }
}
