// ignore_for_file: prefer_const_constructors, use_key_in_widget_constructors

import 'package:NewApp/services/auth.dart';
import 'package:flutter/material.dart';
import 'package:NewApp/constant.dart';
import 'package:NewApp/screen/home/widget/body.dart';
import 'widget/appbar.dart';
import 'package:NewApp/services/database.dart';
import 'package:provider/provider.dart';
import 'package:NewApp/models/member.dart';

class HomeScreen extends StatelessWidget {
  final AuthService _auth = AuthService();
  @override
  Widget build(BuildContext context) {
    return StreamProvider<List<Member>>.value(
      initialData: [],
      value: DatabaseService(uid: '').members,
      child: SafeArea(
        child: Scaffold(
          backgroundColor: backgroundColor,
          appBar: customAppBar(context),
          body: Body(),
        ),
      ),
    );
  }
}
