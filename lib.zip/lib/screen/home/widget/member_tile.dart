import 'package:flutter/material.dart';
import 'package:NewApp/models/member.dart';

class MemberTile extends StatelessWidget {
  final Member member;
  MemberTile({required this.member});
  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(top: 8.0),
        child: Card(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15.0),
          ),
          margin: EdgeInsets.fromLTRB(20.0, 6.0, 20.0, 0.0),
          child: ListTile(
            leading: CircleAvatar(
              radius: 25.0,
              backgroundColor: Colors.blue[400],
            ),
            title: Text(member.name),
            subtitle: Text('Phone number: ${member.phone}'),
          ),
        ));
  }
}
