// ignore_for_file: prefer_const_constructors, sized_box_for_whitespace

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:NewApp/animation/fadeanimation.dart';
import 'package:NewApp/constant.dart';
import 'package:provider/provider.dart';
import 'package:NewApp/models/member.dart';
import 'package:NewApp/screen/home/widget/member_tile.dart';

class Body extends StatefulWidget {
  const Body({Key? key}) : super(key: key);

  @override
  _BodyState createState() => _BodyState();
}

class _BodyState extends State<Body> {
  @override
  Widget build(BuildContext context) {
    final members = Provider.of<List<Member>>(context) ?? [];
    members.forEach((member) {
      print(member.name);
      print(member.phone);
      print(member.borroweditems);
    });
    return ListView.builder(
      itemCount: members.length,
      //cycle thru the item in the member
      itemBuilder: (context, index) {
        return MemberTile(member: members[index]);
      },
    );
  }
}
