// ignore_for_file: prefer_const_constructors

import 'package:NewApp/screen/home/widget/setting_form.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:NewApp/constant.dart';

PreferredSize? customAppBar(context) {
  //for settings function
  void _showSettingsPanel() {
    showModalBottomSheet(
        context: context,
        builder: (context) {
          return Container(
            color: Color(0xffebebeb),
            padding: EdgeInsets.symmetric(vertical: 20.0, horizontal: 60.0),
            child: SettingsForm(),
          );
        });
  }

  return PreferredSize(
    preferredSize: Size.fromHeight(70),
    child: AppBar(
      elevation: 0,
      backgroundColor: Colors.transparent,
      title: Padding(
        padding: EdgeInsets.only(top: 8.0),
        child: Text(
          "Discover",
          style: TextStyle(
            fontSize: 25,
            fontWeight: FontWeight.bold,
            color: darkTextColor,
          ),
        ),
      ),
      actions: [
        //editing icon
        Padding(
          padding: EdgeInsets.only(top: 8.0),
          child: IconButton(
            icon: FaIcon(
              FontAwesomeIcons.pen,
              color: darkTextColor,
              size: 25,
            ),
            onPressed: () {
              _showSettingsPanel();
            },
          ),
        ),
        SizedBox(
          width: 10,
        ),
        //profile setting icon
        Padding(
          padding: EdgeInsets.only(top: 8.0, right: 10),
          child: IconButton(
            icon: FaIcon(
              FontAwesomeIcons.slidersH,
              color: darkTextColor,
              size: 25,
            ),
            onPressed: () {},
          ),
        ),
      ],
    ),
  );
}
