// ignore_for_file: prefer_const_constructors

import 'package:NewApp/loading.dart';
import 'package:NewApp/services/auth.dart';
import 'package:flutter/material.dart';
import 'package:NewApp/constant.dart';
import 'package:NewApp/screen/profile/widget/appbar.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:NewApp/screen/profile/widget/PhoneNoDialog.dart';
import 'package:NewApp/models/user.dart';
import 'package:provider/provider.dart';
import 'package:NewApp/services/database.dart';
import 'package:NewApp/global.dart' as globals;
import 'package:NewApp/login.dart';
import 'package:NewApp/screen/profile/widget/name_form.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:NewApp/models/member.dart';

class Profile extends StatelessWidget {
  final AuthService _auth = AuthService();
  CollectionReference ieeeCollection =
      FirebaseFirestore.instance.collection('members');
  @override
  Widget build(BuildContext context) {
    MyUser? user = Provider.of<MyUser?>(context);
    Size size = MediaQuery.of(context).size;
    Color mainTheme = Color.fromARGB(255, 18, 10, 79);
    void _showNamePanel() {
      showModalBottomSheet(
          context: context,
          builder: (context) {
            return Container(
              color: Color(0xffebebeb),
              padding: EdgeInsets.symmetric(vertical: 20.0, horizontal: 60.0),
              child: NameForm(),
            );
          });
    }

    return StreamProvider<List<Member>>.value(
        initialData: [],
        value: DatabaseService(uid: '').members,
        child: SafeArea(
          child: Scaffold(
            backgroundColor: Color.fromARGB(0, 235, 235, 235),
            appBar: customAppBarProfile(context),
            body: StreamBuilder<UserData>(
              stream: DatabaseService(uid: user!.uid).userData,
              //stream: ieeeCollection.doc(_currentUser!.email).snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData || snapshot.hasError) {
                  return Center(
                    child: Loading(),
                  );
                } else {
                  UserData userData = snapshot.data!;
                  //var data = snapshot.data as DocumentSnapshot;
                  return Container(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Image.asset(
                          'assets/images/profile.png',
                          height: size.height * 0.3,
                        ),
                        SizedBox(height: 20.0),
                        SingleChildScrollView(
                          child: Card(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Container(
                                  width: size.width,
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 20.0,
                                    vertical: 5.0,
                                  ),
                                  child: ListTile(
                                    title: Text(userData.name),
                                    leading: Icon(
                                      Icons.person,
                                      color: mainTheme,
                                    ),
                                    trailing: IconButton(
                                      icon: Icon(Icons.edit),
                                      color: mainTheme,
                                      onPressed: () {
                                        _showNamePanel();
                                      },
                                    ),
                                  ),
                                ),
                                //SizedBox(height: 20.0),
                                Container(
                                  width: size.width,
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 20.0,
                                    vertical: 5.0,
                                  ),
                                  child: ListTile(
                                    title: Text(globals.email),
                                    leading: Icon(
                                      Icons.mail,
                                      color: mainTheme,
                                    ),
                                  ),
                                ),
                                //SizedBox(height: 20.0),
                                Container(
                                  width: size.width,
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 20.0,
                                    vertical: 5.0,
                                  ),
                                  child: ListTile(
                                    title: Text(userData.phone),
                                    leading: Icon(
                                      Icons.phone_android,
                                      color: mainTheme,
                                    ),
                                    trailing: IconButton(
                                      icon: Icon(Icons.edit),
                                      color: mainTheme,
                                      onPressed: () {
                                        PhoneNoDialog dialog =
                                            new PhoneNoDialog();
                                        dialog.ackAlert(context).then((value) {
                                          ieeeCollection
                                              .doc(user.uid)
                                              .update({"phone": value});
                                        });
                                      },
                                    ),
                                  ),
                                ),
                                //SizedBox(height: 20.0),
                                Container(
                                  width: size.width,
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 20.0,
                                    vertical: 5.0,
                                  ),
                                  child: ListTile(
                                    title: Text(
                                      'Logout',
                                      style: TextStyle(
                                          fontSize: 20.0,
                                          fontWeight: FontWeight.w500),
                                    ),
                                    trailing: Icon(Icons.logout),
                                    onTap: () /*async*/ {
                                      //null error if using firebaseauth to logout
                                      //await FirebaseAuth.instance.signOut();
                                      //error here, should auto go to login page without following codes
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) => Login()));
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                }
              },
            ),
          ),
        ));
  }
}
