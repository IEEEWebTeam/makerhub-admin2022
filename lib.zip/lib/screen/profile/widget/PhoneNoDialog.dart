import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
//import 'package:toast/toast.dart';

class PhoneNoDialog {
  TextEditingController _phoneController = TextEditingController();

  Future ackAlert(BuildContext context) {
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Please Enter your phone number.'),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(10.0))),
          content: Container(
            width: 150,
            height: 120,
            child: Column(
              children: [
                TextField(
                  controller: _phoneController,
                  keyboardType: TextInputType.number,
                  maxLength: 11,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  decoration: InputDecoration(hintText: "No'-' is needed"),
                ),
                SizedBox(
                  height: 10,
                ),
                Text("This is for internal use only.")
              ],
            ),
          ),
          actions: [
            TextButton(
              child: Text('Ok'),
              onPressed: () {
                if (_phoneController.text.isEmpty) {
                  Fluttertoast.showToast(
                      msg: "Please Enter Your Phone Number.",
                      toastLength: Toast.LENGTH_SHORT,
                      gravity: ToastGravity.BOTTOM);
                } else {
                  Navigator.of(context).pop(_phoneController.text);
                }
              },
            ),
          ],
        );
      },
    );
  }
}
