import 'package:NewApp/screen/navigator.dart';
import 'package:flutter/material.dart';
import 'package:NewApp/constant.dart';

PreferredSize? customAppBarProfile(context) {
  return PreferredSize(
    preferredSize: Size.fromHeight(60),
    child: AppBar(
      leading: Padding(
        padding: EdgeInsets.only(top: 8.0),
        child: IconButton(
          icon: Icon(Icons.arrow_back_ios),
          color: darkTextColor,
          onPressed: () {
            Navigator.pushReplacement(context,
                MaterialPageRoute(builder: (context) => MainNavigator()));
          },
        ),
      ),
      centerTitle: true,
      elevation: 0,
      backgroundColor: Colors.transparent,
      title: Padding(
        padding: EdgeInsets.only(
          top: 8.0,
        ),
        child: Text(
          "My Profile",
          style: TextStyle(
            fontSize: 25,
            fontWeight: FontWeight.bold,
            color: darkTextColor,
          ),
        ),
      ),
      actions: [
        Padding(
          padding: EdgeInsets.only(top: 8.0, right: 5),
          child: IconButton(
            icon: Icon(Icons.more_vert),
            color: darkTextColor,
            onPressed: () {},
          ),
        ),
      ],
    ),
  );
}
