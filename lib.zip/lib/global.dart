library my_prj.globals;

String email = '';
