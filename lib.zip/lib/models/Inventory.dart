import 'package:flutter/material.dart';

class Inventory {
  String? _item;
  int? _totalAmount;
  int? _available;

  Inventory(this._item, this._totalAmount, this._available);

  String get item => _item!;
  int get totalAmount => _totalAmount!;
  int get borrowed => _available!;

  /*inventory(String item, int totalAmount, int available) {
    this._item = item;
    this._totalAmount = totalAmount;
    this._available = _available;
  }*/

  set item(String item) {
    this._item = item;
  }

  set totalAmount(int totalAmount) {
    this._totalAmount = totalAmount;
  }

  set borrowed(int borrowed) {
    this._available = borrowed;
  }

  int remaining() => _totalAmount! - _available!;
}
