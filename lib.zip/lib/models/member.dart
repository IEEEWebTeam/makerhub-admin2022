//make sure to use the same data type as auth.dart & database.dart
class Member {
  final String name;
  final String phone;
  final String borroweditems;

  Member({
    required this.name,
    required this.phone,
    required this.borroweditems,
  });
}
