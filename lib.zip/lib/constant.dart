import 'package:flutter/material.dart';

final Color backgroundColor = Color.fromARGB(20, 235, 235, 235);
final Color darkTextColor = Color(0xff171717);
final Color lightTextColor = Colors.white;
final Color unSelectedtextColor = Color(0xffc9c9c9);
final Color materialButtonColor = Colors.blue;

const textInputDecoration = InputDecoration(
  fillColor: Colors.white,
  filled: true,
  contentPadding: EdgeInsets.all(12.0),
  enabledBorder: OutlineInputBorder(
    borderSide: BorderSide(color: Colors.white, width: 2.0),
  ),
  focusedBorder: OutlineInputBorder(
    borderSide: BorderSide(color: Colors.blue, width: 2.0),
  ),
);
