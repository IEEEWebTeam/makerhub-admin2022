import 'package:NewApp/loading.dart';
import 'package:NewApp/login.dart';
import 'package:NewApp/screen/navigator.dart';
import 'package:NewApp/services/auth.dart';
import 'package:flutter/material.dart';
import 'package:NewApp/constant.dart';
import 'global.dart' as globals;

class Register extends StatefulWidget {
  const Register({Key? key}) : super(key: key);

  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  final AuthService _auth = AuthService();
  final _formKey = GlobalKey<FormState>();
  //text field state
  String password1 = '';
  String password2 = '';
  String error = '';

  //for loading widget
  bool loading = false;
  @override

  // Toggles the password show status
  bool _obscureText = true;
  void _toggle() {
    setState(() {
      _obscureText = !_obscureText;
    });
  }

  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    Color mainTheme = Color.fromARGB(255, 18, 10, 79);
    return loading
        ? Loading()
        : Scaffold(
            backgroundColor: Colors.white,
            appBar: AppBar(
              backgroundColor: Colors.white,
              elevation: 0.0,
              title: Text(
                'Register to IEEE CCSB makerhub',
                style: TextStyle(color: Colors.black),
                textAlign: TextAlign.center,
              ),
              centerTitle: true,
              leading: Padding(
                padding: EdgeInsets.only(top: 8.0),
                child: IconButton(
                  icon: Icon(Icons.arrow_back_ios),
                  color: darkTextColor,
                  onPressed: () {
                    Navigator.pushReplacement(context,
                        MaterialPageRoute(builder: (context) => Login()));
                  },
                ),
              ),
            ),
            body: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Padding(
                        padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
                        child: Container(
                            decoration: BoxDecoration(
                              color: Colors.blue[50],
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            child: Padding(
                                padding: EdgeInsets.only(
                                    left: 15, right: 15, top: 5),
                                child: TextFormField(
                                    validator: (val) =>
                                        val!.isEmpty ? 'Enter an email' : null,
                                    onChanged: (val) {
                                      setState(() {
                                        globals.email = val;
                                      });
                                    },
                                    decoration: InputDecoration(
                                      icon: Icon(
                                        Icons.mail_sharp,
                                        color: mainTheme,
                                      ),
                                      border: InputBorder.none,
                                      labelText: 'Email',
                                    ))))),
                    Padding(
                      padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
                      child: Stack(
                        children: <Widget>[
                          Container(
                              decoration: BoxDecoration(
                                color: Colors.blue[50],
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              child: Padding(
                                  padding: EdgeInsets.only(
                                      left: 15, right: 15, top: 5),
                                  child: TextFormField(
                                      validator: (val) => val!.length < 8
                                          ? 'Enter a password with 8 chars long'
                                          : null,
                                      onChanged: (val) {
                                        password1 = val;
                                      },
                                      obscureText: _obscureText,
                                      decoration: InputDecoration(
                                        icon: Icon(
                                          Icons.lock_sharp,
                                          color: mainTheme,
                                        ),
                                        border: InputBorder.none,
                                        labelText: 'Your password',
                                        suffixIcon: IconButton(
                                          icon: Icon(Icons.visibility),
                                          color: mainTheme,
                                          onPressed: _toggle,
                                        ),
                                      )))),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
                      child: Stack(
                        children: <Widget>[
                          Container(
                              decoration: BoxDecoration(
                                color: Colors.blue[50],
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              child: Padding(
                                  padding: EdgeInsets.only(
                                      left: 15, right: 15, top: 5),
                                  child: TextFormField(
                                      validator: (val) => val!.length < 8
                                          ? 'Enter a password with 8 chars long'
                                          : null,
                                      onChanged: (val) {
                                        password2 = val;
                                      },
                                      obscureText: true,
                                      decoration: InputDecoration(
                                        icon: Icon(
                                          Icons.verified_user_sharp,
                                          color: mainTheme,
                                        ),
                                        border: InputBorder.none,
                                        labelText: 'Re-type your password',
                                      )))),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: Container(
                        height: size.height * 0.06,
                        width: size.width * 0.8,
                        child: RaisedButton(
                          elevation: 5.0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30.0),
                          ),
                          color: Colors.blue[50],
                          child: Text('Register',
                              style: TextStyle(
                                  color: mainTheme,
                                  fontSize: 18.0,
                                  letterSpacing: 2.0,
                                  fontWeight: FontWeight.bold)),
                          onPressed: () async {
                            dynamic result;
                            if (!verification(globals.email)) {
                              result = null;
                            } else if (!passVerification(
                                password1, password2)) {
                              result = 0;
                            } else {
                              if (_formKey.currentState!.validate()) {
                                setState(() => loading = true);
                                result =
                                    await _auth.registerWithEmailAndPassword(
                                        globals.email, password1);
                              }
                            }
                            if (result == null) {
                              setState(() {
                                loading = false;
                                error = 'Please supply a valid student email';
                              });
                            } else if (result == 0) {
                              setState(() {
                                loading = false;
                                error = 'Password not match!';
                              });
                            } else {
                              Loading();
                              //got issue here, should hv auto go to home screen without the following codes
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => MainNavigator()));
                            }
                          },
                        ),
                      ),
                    ),
                    SizedBox(height: 12.0),
                    Text(
                      error,
                      style: TextStyle(color: Colors.red, fontSize: 14.0),
                    )
                  ],
                )));
  }
}

bool verification(String email) {
  if (email.endsWith("curtin.edu.my")) return true;
  return false;
}

bool passVerification(String pass1, String pass2) {
  if (pass1 != pass2) {
    return false;
  } else {
    return true;
  }
}
