import 'package:NewApp/models/user.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:NewApp/models/member.dart';

class DatabaseService {
  final String uid;
  DatabaseService({required this.uid});

  //collection reference
  final CollectionReference ieeeCollection =
      FirebaseFirestore.instance.collection('members');
  //make sure the data type in updateUserData() same as inventory.dart&auth.dart
  Future<void> updateUserData(
      String name, String phone, String borroweditems) async {
    return await ieeeCollection.doc(uid).set({
      'name': name,
      'phone': phone,
      'borroweditems': borroweditems,
      //'cart': cart,
    });
  }

//inventory list from snapshot
  List<Member> _memberListFromSnapshot(QuerySnapshot snapshot) {
    try {
      return snapshot.docs.map((doc) {
        return Member(
          name: doc.get('name') ?? '',
          phone: doc.get('phone') ?? '',
          borroweditems: doc.get('borroweditems') ?? '',
        );
      }).toList();
    } catch (e) {
      print(e.toString());
      return [];
    }
  }

//userData from snapshot
  UserData _userDataFromSnapshot(DocumentSnapshot snapshot) {
    return UserData(
      uid: uid,
      name: snapshot['name'],
      phone: snapshot['phone'],
      borroweditems: snapshot['borroweditems'],
      //cart: snapshot['cart']
    );
  }

//get inventory stream
  Stream<List<Member>> get members {
    return ieeeCollection.snapshots().map(_memberListFromSnapshot);
  }

  //get user doc stream
  Stream<UserData> get userData {
    return ieeeCollection.doc(uid).snapshots().map(_userDataFromSnapshot);
  }
}
